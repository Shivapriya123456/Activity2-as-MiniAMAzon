package com.capgemini.ma.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.ma.bean.Item;
import com.capgemini.ma.exception.MAException;
import com.capgemini.ma.utility.ItemRepositories;

public class ItemDaoImpl implements ItemDao {

	@Override
	public List<Item> getItems() throws MAException {
		
		return null;
	}

	@Override
	public Map<Integer, Item> getAllItems() throws MAException {
		
		return ItemRepositories.getItemList();
	}

}
