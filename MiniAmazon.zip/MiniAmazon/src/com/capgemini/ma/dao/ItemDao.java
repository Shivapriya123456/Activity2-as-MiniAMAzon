package com.capgemini.ma.dao;

import java.util.List;
import java.util.Map;

import com.capgemini.ma.bean.Item;
import com.capgemini.ma.exception.MAException;

public interface ItemDao {

	List<Item> getItems() throws MAException;

	public Map<Integer, Item> getAllItems()throws MAException;

}
