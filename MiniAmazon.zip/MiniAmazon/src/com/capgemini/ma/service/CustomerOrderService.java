package com.capgemini.ma.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.capgemini.ma.bean.Item;
import com.capgemini.ma.bean.Order;
import com.capgemini.ma.exception.MAException;

public interface CustomerOrderService {
	
	static Map<Integer, Order> orderMap=new HashMap<>();

	boolean isNameValidate(String name)throws MAException;

	boolean isMobileValid(long mobile)throws MAException;
	
	boolean addToCart(Order item)throws MAException;
	
	List<Order> printOrderedItems()throws MAException;
	
	public List<Item> getItems()throws MAException;


	boolean isQuantityValid(int itemQuantity)throws MAException;

	public Map<Integer, Item> getAllItems() throws MAException;

	void isValid(int itemId);

	//double addToCart(int itemId, String itemName, double itemPrice) throws MAException;

}
