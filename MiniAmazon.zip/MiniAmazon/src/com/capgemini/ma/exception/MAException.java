package com.capgemini.ma.exception;

public class MAException extends Exception{

	public MAException(String message) {
		super(message);
		
	}
	
	

}
